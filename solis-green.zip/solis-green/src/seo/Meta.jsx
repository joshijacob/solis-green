import React from "react";
import { Helmet } from "react-helmet";

export default function Meta({ title, description }) {
  return (
    <Helmet>
      <title>{title || "Solis Green Energy Solutions"}</title>
      <meta name="description" content={description || "Solar EPC in Kerala"} />
    </Helmet>
  );
}
