import React from "react";
import Meta from "../seo/Meta";
import ContactForm from "../components/ContactForm";

export default function Residential() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Meta
        title="Residential Solar Systems in Kerala | Solis Green"
        description="Custom rooftop solar systems for Kerala homes. Free site visit, MNRE assistance and local installation support."
      />

      <h1 className="text-3xl font-bold mb-4">Residential Solar Systems</h1>

      <p className="text-gray-700 mb-4">
        We design and install efficient rooftop solar systems tailored for houses in Kerala.
        Our residential packages focus on maximizing household savings while ensuring reliable,
        low-maintenance performance with local service support.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="font-semibold text-xl mb-2">Our Residential Process</h2>
          <ol className="list-decimal ml-5 space-y-2 text-gray-700">
            <li>Free site survey & daily energy assessment</li>
            <li>Custom system design & detailed quotation</li>
            <li>Professional installation with net-metering support</li>
            <li>System commissioning & post-installation monitoring</li>
          </ol>

          <h3 className="font-semibold text-lg mt-6">Why choose us?</h3>
          <ul className="list-disc ml-5 mt-2 text-gray-700">
            <li>MNRE & KSEB compliant installations</li>
            <li>Local technicians and fast support</li>
            <li>Quality panels & string / micro-inverter options</li>
            <li>Warranty & AMC options available</li>
          </ul>
        </div>

        <div>
          <div className="mb-4">
            <h3 className="font-semibold">Get a Free Quote</h3>
            <p className="text-sm text-gray-600">Enter simple details and we will call you back for a site visit.</p>
          </div>
          <ContactForm />
        </div>
      </div>

      <section className="mt-8">
        <h3 className="font-semibold text-xl mb-2">Typical Residential Packages</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="border p-4 rounded">
            <h4 className="font-semibold">3 kW Package</h4>
            <p className="text-sm text-gray-700 mt-2">Suitable for small households. Basic inverters and panels.</p>
          </div>
          <div className="border p-4 rounded">
            <h4 className="font-semibold">5 kW Package</h4>
            <p className="text-sm text-gray-700 mt-2">Most common for medium homes. Balanced cost & savings.</p>
          </div>
          <div className="border p-4 rounded">
            <h4 className="font-semibold">10 kW+ Package</h4>
            <p className="text-sm text-gray-700 mt-2">For large homes or heavy electricity needs.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
