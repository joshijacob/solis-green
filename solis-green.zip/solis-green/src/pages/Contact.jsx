import React from "react";
import Meta from "../seo/Meta";
import ContactForm from "../components/ContactForm";

export default function Contact() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Meta
        title="Contact Us - Solis Green Energy Solutions"
        description="Contact Solis Green Energy Solutions for free site visit, quote, and solar services in Kerala."
      />

      <h1 className="text-3xl font-bold mb-4">Contact Us</h1>

      <p className="text-gray-700 mb-4">
        Call us: <a className="text-primary" href="tel:+918301849474">+91 8301849474</a>,{" "}
        <a className="text-primary" href="tel:+919539316623">+91 9539316623</a>
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-semibold">Request a Free Site Visit</h3>
          <ContactForm />
        </div>

        <div>
          <h3 className="font-semibold">Visit / Mail</h3>
          <p className="text-gray-700">Muthoor, Thiruvalla, Pathanamthitta, Kerala</p>
          <p className="text-gray-700 mt-2">Email: <a className="text-primary" href="mailto:solisgreenindia@gmail.com">solisgreenindia@gmail.com</a></p>

          <div className="mt-4">
            <h4 className="font-semibold">Find us on map</h4>
            <div className="mt-2">
              <iframe
                title="Solis Green Location"
                src="https://www.google.com/maps/embed?pb=!1m18"
                width="100%"
                height="260"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
