import React from "react";
import Calculator from "../components/Calculator";
import ContactForm from "../components/ContactForm";
import Meta from "../seo/Meta";

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Meta title="Solis Green Energy Solutions - Kerala Solar Experts" />
      <h1 className="text-3xl font-bold mb-4">Solis Green Energy Solutions</h1>
      <p className="mb-6 text-gray-700">
        MNRE approved solar EPC in Thiruvalla serving Kerala homes & businesses.
      </p>
      <div className="grid md:grid-cols-2 gap-6">
        <Calculator />
        <ContactForm />
      </div>
    </div>
  );
}
