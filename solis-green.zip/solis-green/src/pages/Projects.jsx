import React from "react";
import Meta from "../seo/Meta";

export default function Projects() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Meta
        title="Projects - Solis Green Energy Solutions"
        description="Case studies, installations and gallery of Solis Green Energy Solutions' solar projects across Kerala."
      />

      <h1 className="text-3xl font-bold mb-4">Projects & Case Studies</h1>

      <p className="text-gray-700 mb-4">
        A selection of our completed installations — residential and commercial projects with performance highlights.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="border rounded p-3">
          <h4 className="font-semibold">5 kW Residential - Thiruvalla</h4>
          <p className="text-sm text-gray-600 mt-2">Estimated savings: ₹3,500/month — Installed 2024.</p>
        </div>
        <div className="border rounded p-3">
          <h4 className="font-semibold">20 kW Commercial - Kottayam</h4>
          <p className="text-sm text-gray-600 mt-2">Rooftop for retail complex — Phase 1 completed 2023.</p>
        </div>
        <div className="border rounded p-3">
          <h4 className="font-semibold">AMC Contract - School Campus</h4>
          <p className="text-sm text-gray-600 mt-2">Annual maintenance & performance monitoring.</p>
        </div>
      </div>

      <section className="mt-8">
        <h3 className="font-semibold text-xl mb-2">Want your project featured?</h3>
        <p className="text-gray-700">If you are a client, share your feedback & photos — we may feature your project as a case study.</p>
      </section>
    </div>
  );
}
