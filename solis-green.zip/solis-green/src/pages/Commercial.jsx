import React from "react";
import Meta from "../seo/Meta";
import ContactForm from "../components/ContactForm";

export default function Commercial() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Meta
        title="Commercial Solar EPC Kerala | Solis Green"
        description="Commercial & industrial solar EPC services in Kerala. Energy audits, project management and O&M for businesses."
      />

      <h1 className="text-3xl font-bold mb-4">Commercial Solar Systems</h1>

      <p className="text-gray-700 mb-4">
        We deliver end-to-end commercial solar projects for shops, offices, schools, hospitals and factories.
        Our EPC services include design, procurement, installation and long-term O&M.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="font-semibold text-xl">Services for Commercial Clients</h2>
          <ul className="list-disc ml-5 mt-2 text-gray-700">
            <li>Site energy audit & financial modelling</li>
            <li>Custom design & structural assessment</li>
            <li>Procurement management & certified installation</li>
            <li>Operation & Maintenance (O&M) contracts</li>
          </ul>

          <h3 className="font-semibold text-lg mt-6">Benefits</h3>
          <ul className="list-disc ml-5 mt-2 text-gray-700">
            <li>Lower operating costs & predictable energy bills</li>
            <li>Faster payback with correct sizing and incentives</li>
            <li>Scalable systems (phased expansion possible)</li>
          </ul>
        </div>

        <div>
          <h3 className="font-semibold">Request Commercial Proposal</h3>
          <p className="text-sm text-gray-600 mb-2">Provide basic details and our team will prepare an audit & proposal.</p>
          <ContactForm />
        </div>
      </div>

      <section className="mt-8">
        <h3 className="font-semibold text-xl mb-2">Completed Commercial Projects</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="border p-3 rounded">20 kW rooftop for a retail complex - Kottayam</div>
          <div className="border p-3 rounded">50 kW industrial rooftop - Industrial Estate</div>
          <div className="border p-3 rounded">30 kW school campus - Pathanamthitta</div>
        </div>
      </section>
    </div>
  );
}
