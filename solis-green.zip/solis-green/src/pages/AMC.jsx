import React from "react";
import Meta from "../seo/Meta";
import ContactForm from "../components/ContactForm";

export default function AMC() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Meta
        title="Solar AMC & Maintenance Kerala | Solis Green"
        description="Scheduled solar AMC, inverter repair, panel cleaning and system optimization services across Kerala."
      />

      <h1 className="text-3xl font-bold mb-4">Solar AMC & Maintenance</h1>

      <p className="text-gray-700 mb-4">
        Regular maintenance is essential to keep your solar system producing at its rated capacity.
        Our AMC plans cover inspections, cleaning, electrical checks, inverter health and priority support.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="font-semibold text-xl">AMC Plans & Services</h2>
          <ul className="list-disc ml-5 mt-2 text-gray-700">
            <li>Quarterly inspection & solar cleaning</li>
            <li>Inverter checks and firmware updates</li>
            <li>Performance monitoring & report</li>
            <li>Priority emergency service & spare parts support</li>
          </ul>

          <h3 className="font-semibold text-lg mt-6">Why AMC?</h3>
          <p className="text-gray-700">AMCs reduce downtime, protect warranties, and ensure long-term energy yield.</p>
        </div>

        <div>
          <h3 className="font-semibold">Book AMC / Service</h3>
          <p className="text-sm text-gray-600">Enter your details and we will schedule a technician visit.</p>
          <ContactForm />
        </div>
      </div>

      <section className="mt-8">
        <h3 className="font-semibold text-xl mb-2">Common Service Requests</h3>
        <ul className="list-disc ml-5 text-gray-700">
          <li>Panel cleaning & bird-nest removal</li>
          <li>Inverter fault diagnosis & repair</li>
          <li>Metering & net-metering assistance</li>
          <li>Performance drop investigation</li>
        </ul>
      </section>
    </div>
  );
}
