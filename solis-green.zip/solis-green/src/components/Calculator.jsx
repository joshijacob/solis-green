import React, { useState } from "react";

export default function Calculator() {
  const [bill, setBill] = useState("");
  const [result, setResult] = useState(null);

  const calc = (e) => {
    e.preventDefault();
    const b = parseFloat(bill);
    if (!b) return;
    const kWh = b / 7.5;
    const reqKW = Math.ceil((kWh / 105) * 10) / 10;
    const cost = Math.round(reqKW * 60000);
    setResult({ reqKW, cost });
  };

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="font-semibold">Solar ROI Calculator</h3>
      <form onSubmit={calc} className="space-y-2 mt-2">
        <input
          value={bill}
          onChange={(e) => setBill(e.target.value)}
          className="border w-full p-2 rounded"
          placeholder="Monthly Bill ₹"
        />
        <button className="bg-primary text-white px-3 py-1 rounded w-full">Estimate</button>
      </form>
      {result && (
        <p className="mt-2 text-sm">
          Recommended {result.reqKW} kW ≈ ₹{result.cost.toLocaleString()}
        </p>
      )}
    </div>
  );
}
