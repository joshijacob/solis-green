import React from "react";

export default function Footer() {
  return (
    <footer className="bg-gray-100 border-t mt-8 text-sm">
      <div className="container mx-auto px-4 py-6 grid md:grid-cols-3 gap-4">
        <div>
          <h3 className="font-bold">Solis Green Energy Solutions</h3>
          <p>Muthoor, Thiruvalla, Pathanamthitta, Kerala</p>
          <p>📞 8301849474 / 9539316623</p>
          <p>✉️ solisgreenindia@gmail.com</p>
        </div>
        <div>
          <p className="font-semibold">Services</p>
          <ul className="list-disc ml-5">
            <li>Residential Solar</li>
            <li>Commercial Solar</li>
            <li>Solar AMC</li>
          </ul>
        </div>
        <div>
          <p className="font-semibold">Follow Us</p>
          <p>Facebook | Instagram | LinkedIn</p>
        </div>
      </div>
      <p className="text-center text-xs text-gray-500 py-2">
        © {new Date().getFullYear()} Solis Green Energy Solutions
      </p>
    </footer>
  );
}
