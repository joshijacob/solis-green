import React from "react";

export default function CTAFloat() {
  return (
    <>
      <a
        href="https://wa.me/918301849474"
        className="fixed bottom-20 right-4 bg-[#25D366] p-3 rounded-full shadow-lg text-white z-50"
        target="_blank" rel="noreferrer"
      >💬</a>
      <a
        href="tel:+918301849474"
        className="fixed bottom-4 right-4 bg-primary p-3 rounded-full shadow-lg text-white z-50"
      >📞</a>
    </>
  );
}
