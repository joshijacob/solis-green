import React, { useState } from "react";

export default function ContactForm() {
  const [sent, setSent] = useState(false);
  const handleSubmit = (e) => { e.preventDefault(); setSent(true); };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow space-y-3">
      {sent && <div className="text-green-600">Thanks! We’ll contact you soon.</div>}
      <input className="border w-full p-2 rounded" placeholder="Your Name" required />
      <input className="border w-full p-2 rounded" placeholder="Phone" required />
      <textarea className="border w-full p-2 rounded" rows="3" placeholder="Message" />
      <button className="bg-primary text-white px-4 py-2 rounded w-full">Request Free Site Visit</button>
    </form>
  );
}
